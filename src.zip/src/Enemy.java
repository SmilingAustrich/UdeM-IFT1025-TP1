public class Enemy extends Character{

    private int experienceDrop;
    public Enemy(int health, int maxHealth, int attackpoint, int experienceDrop){
        super(health, maxHealth, attackpoint);
        this.experienceDrop = experienceDrop;

    }

    @Override
    public void attack(Character hero){
        int health = hero.getHealth();
        int newHealth = health - this.getAttackPoint();
        hero.setHealth( newHealth );
    }
}
