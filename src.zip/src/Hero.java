
public class Hero extends Character {

    private int experience, level, experienceRequired;
    private String heroName;
    public Hero(int health, int maxHealth, int attackPoint, int experience, int level, int experienceRequired) {
        super(health, maxHealth, attackPoint);
        this.experience = experience;
        this.level = level;
        this.experienceRequired = experienceRequired;
    }

    public void setExperience( int experience ){
        this.experience = experience;
    };
    public void setLevel( int level ){
        this.level = level;
    };
    public void setExperienceRequired( int experienceRequired ){
        this.experienceRequired = experienceRequired;
    };
    @Override
    public void attack( Character enemy ){
        int health = enemy.getHealth();
        int newHealth = health - this.getAttackPoint();
        enemy.setHealth( newHealth );
    }
}
